export type Profile = {
  id: string;
  full_name: string;
  role: "customer" | "provider" | "admin";
  city: string | null;
  phone: string | null;
  avatar_url: string | null;
  provider_approved: boolean;
  created_at?: string;
};

export type Category = {
  id: string;
  name: string;
  icon: string;
  slug: string;
};

export type ProviderService = {
  id: string;
  provider_id: string;
  category_id: string;
  title: string;
  description: string;
  city: string;
  price_text: string;
  is_active: boolean;
  created_at?: string;
  profiles?: Profile;
  categories?: Category;
};

export type ServiceRequest = {
  id: string;
  customer_id: string;
  provider_id: string;
  service_id: string;
  details: string;
  city: string;
  preferred_date: string | null;
  status: "pending" | "accepted" | "in_progress" | "completed" | "cancelled" | "rejected";
  created_at: string;
  provider_services?: ProviderService;
};

export type Review = {
  id: string;
  request_id: string;
  customer_id: string;
  provider_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
};
